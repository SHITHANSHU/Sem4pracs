#include<iostream>
#include<graphics.h>
using namespace std;
int x[10],y[10],sx,sy,old_color,new_color,i;

class point
{
public:
int x1,y1,n;

public:
void getdata();
void init();

};

class polygon:public point
{

public:
void draw_polygon(int x[],int y[]);
void flood_fill(int,int,int,int);
//void bound_fill(int,int,int,int);
};


void point::getdata()
{

cout<<"\nEnter the total no of vertices: ";
cin>>n;
for(i=0;i<n;i++)
{
 cout<<"\nEnter the x and y coordinate of "<<i+1<<"vertex: ";
 cin>>x[i]>>y[i];
}
 
 cout<<"\nEnter the old color and new color ";
 cin>>old_color>>new_color;
 cout<<"\nEnter the x and y coordinates of seed pixel ";
 cin>>sx>>sy;
}

void point::init()
{
 int gm=VGAMAX,gd=DETECT;
 initgraph(&gm,&gd,NULL);
}

void polygon::draw_polygon(int x[],int y[])
{
for(i=0;i<n-1;i++)
 {
  line(x[i],y[i],x[i+1],y[i+1]);
  }
 line(x[n-1],y[n-1],x[0],y[0]);
}

void polygon::flood_fill(int x,int y,int new_color,int old_color)
 {
  if(getpixel(x,y)==old_color)
   {
    delay(5);
    putpixel(x,y,new_color);
    flood_fill(x+1,y,new_color,old_color);
    flood_fill(x-1,y,new_color,old_color);
    flood_fill(x,y-1,new_color,old_color);
    flood_fill(x,y+1,new_color,old_color);
 }}

int main()
{
polygon ob;
ob.getdata();
ob.init();
ob.draw_polygon(x,y);
ob.flood_fill(sx,sy,new_color,old_color);
delay(50000000);
closegraph();
return 0;
}
