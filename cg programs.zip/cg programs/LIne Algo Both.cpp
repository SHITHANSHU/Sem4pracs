#include<iostream>
#include<graphics.h>
#include<math.h>
#include<stdlib.h>
using namespace std;
void dda_algo(int x1,int y1,int x2,int y2);
void bresenham_algo(int x1,int y1,int x2,int y2);
int Sign (int arg);
int main()
{
	int gd=DETECT,gm=VGAMAX;int choice;
	initgraph(&gd,&gm,NULL);
	int x1,y1,x2,y2;
	char ch;
	do
	{
	
		cout<<"1.DDA algorithm\n2.Bresenham's algorithm\n3.Clearscreen\n4.Exit";
		cout<<"\nEnter your choice:";
		cin>>choice;
		switch(choice)
		{
			case 1:cout<<"\n------DDA line generation algorithm-------------";
			cout<<"\nEnter x1:";
			cin>>x1;
			cout<<"\nEnter y1:";
			cin>>y1;
			cout<<"\nEnter x2:";
			cin>>x2;
			cout<<"\nEnter y2:";
			cin>>y2;
			dda_algo(x1,y1,x2,y2);
			break;
			case 2:cout<<"\n------Bresenham's line generation algorithm-------------";
			cout<<"\nEnter x1:";
			cin>>x1;
			cout<<"\nEnter y1:";
			cin>>y1;
			cout<<"\nEnter x2:";
			cin>>x2;
			cout<<"\nEnter y2:";
			cin>>y2;
			bresenham_algo(x1,y1,x2,y2);
			break;
			case 3:
				cleardevice();
				break;
			case 4:
			exit(0);
			default:cout<<"\nInvalide choice";
			
		}
		cout<<"Do u want to continue...(Y or N):";
		cin>>ch;
	}while(ch=='Y'||ch=='y');
	getch();
	closegraph();
	delay(3000);
	return 0;
}
/*------------------------------- function definations-----------------------------------------------------*/
void dda_algo(int x1,int y1,int x2,int y2)
{
	int i, dx,dy,steps;
	float x,y;
	float xinc,yinc;
	dx=(x2-x1);
	dy=(y2-y1);
	
	if(abs(dx)>=abs(dy))
	{
		steps=dx;
	}
	else
		steps=dy;
	xinc=(float)dx/steps;
	yinc=(float)dy/steps;
	x=x1;
	y=y1;
	putpixel(x,y,WHITE);
	for(i=1;i<steps;i++)
	{
		x=x+xinc;
		y=y+yinc;
		x1=x+0.5;
		y1=y+0.5;
		putpixel(x1,y1,WHITE);
		delay(10);
	}
	/*getch();
	closegraph();
	delay(3000);*/
}
void bresenham_algo(int x1,int y1,int x2,int y2)
{
	int s1,s2,x,y,i,exchange;int k=x2-x1,m=y2-y1;
	float dx,dy,g,temp;
	dx=abs(x2-x1);
	dy=abs(y2-y1);
	x=x1;
	y=y1;
	s1 = Sign(x2-x1);
	s2 = Sign(y2-y1);
	if(dy>dx)
	{
		temp=dx;
		dx=dy;
		dy=temp;
		exchange=1;
	}
	else
	exchange=0;
	g=2*dy-dx;
	i=1;
	while(i<=dx)
	{
		putpixel(x,y,WHITE);
		delay(10);
		while(g>=0)
		{
			if(exchange==1)
			x=x+s1;
			else
			y=y+y2;
			g=g+2*dy-2*dx;
		}
		if(exchange==1)
		y=y+s2;
		else
		x=x+s1;
		g=g+2*dy;
		i++;
	}
	/*getch();
	delay(3000);
	closegraph();*/

}
int Sign (int arg)
{
	if(arg<0)
	return -1;
	else if(arg==0)
	return 0;
	else
		return 1;
}

