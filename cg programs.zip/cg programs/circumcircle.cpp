#include<iostream>
#include<graphics.h>
#include<math.h>
using namespace std;
class Pixel   //base classi 
{

    protected: int xco,yco,color;

    public:
    Pixel()
    {
        xco=0;yco=0;color=2;
    }

    void setCoordinate(int x,int y)
    {  
        xco=x;
        yco=y;
    }  

    void setColor(int c)  
    {  
        color=c;
    }

    void drawCircle(int xc, int yc, int x, int y)
    {
       	putpixel(xc+x, yc+y, 3);
        putpixel(xc-x, yc+y, 4);
 	putpixel(xc+x, yc-y, BLUE);
        putpixel(xc-x, yc-y, YELLOW);
	putpixel(xc+y, yc+x, WHITE);
	putpixel(xc-y, yc+x, 1);
	putpixel(xc+y, yc-x, 8);
	putpixel(xc-y, yc-x, RED);
    }
};

class DrawBresCircle:public Pixel
{
    private:int radius;

    public:
    DrawBresCircle()
    {
         radius = 0;
    }

    void circleBres(int xc, int yc, int r); //Bresenham's Logic
};

void DrawBresCircle::circleBres(int xc, int yc, int r)
    {
	int x = 0, y = r;
	int d = 3 - 2 * r;
		while (x < y)
		{
			Pixel::drawCircle(xc, yc, x, y);
			x++;
		if (d < 0)
			d = d + 4 * x + 6;
		else
			{
				y--;
				d = d + 4 * (x - y) + 10;
			}
		}	
    } 

int main()
{
int gd=DETECT,gm=VGAMAX;
float x1,x2,x3,y1,y2,y3,xmid,ymid,xc,yc,xx,yy;

DrawBresCircle dsb;
//cout<<"enter coordinates of tringle\n";
//cin>>x1>>y1>>x2>>y2>>x3>>y3;
x1=200;y1=200;x2=300;y2=200;x3=250;y3=286.663;


xc=x1+((x2-x1)/2);
yc=y2+((y3-y2)/3);
float rcc;
if(y3>y2)
rcc=(y3-y2)/3;
if(y2>y3)
rcc=(y2-y3)/3;
initgraph(&gd,&gm,NULL);

line(x1,y1,x2,y2);
line(x2,y2,x3,y3);
line(x3,y3,x1,y1);

dsb.circleBres(xc,yc,rcc);      //////////incircle
dsb.circleBres(xc,yc,rcc*2);   //////////circumcircle

delay(100000);
closegraph();
return 0;
}
