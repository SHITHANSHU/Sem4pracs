
// Assignment No. 6 
// Symbol Table

#include<iostream>
#include<string>

using namespace std;

#define TRUE 1
#define FALSE 0

class SymbolTable
{

private:
	struct node
	{
		string identifier;
		double initial_value;
		int total_lines_of_id;
		int lines_no[50];
		struct node *next;

	}*head;

public:
	SymbolTable();
	void create();
	void display();
	void is_name_present();
	void retrieve_attributes();
	void modify_attributes();
	void insert();
	void delete_id();
	~SymbolTable();


};


/* Constructor defined */

SymbolTable::SymbolTable()
{
	head=NULL; //initialize head to NULL


}

/* Destructor defined */

SymbolTable::~SymbolTable()
{

	node *temp,*temp1;
	temp=head->next;
	delete head;
	while(temp!=NULL) // free the memory allocated
	{
		temp1=temp->next;
		delete temp;
		temp=temp1;
		

	}

}

/* create function */

void SymbolTable::create()
{
	node *temp,*New;
	int flag,i;
	string id;
	char ans='y',ch='y';
	temp=NULL;
	New=NULL;
	flag=TRUE;
	
	do
	{

		New = new node;
		if(New==NULL)
		{

			cout<<"Unable to allocate memory \n";
			return;

		}
		cout<<"\n Enter the name of Identifier";
		cin>>New->identifier;

		cout<<"\n Enter initial value";
		cin>>New->initial_value;
		i=0;

		do
		{
			cout<<"\n Enter line number";
			cin>>New->lines_no[i];
			i++;
			cout<<"Do u want to enter more line numbers? ";
			cin>>ch;

		}while(ch=='y'||ch=='Y');

		New->total_lines_of_id=i-1; // stroring total no. of lines for that id

		New->next=NULL;

		if(flag==TRUE) //Executed only for the first time
		{
			head=New;
			temp=head;
			flag=FALSE;

		}

		else
		{
			//temp last keeps  track of the most recently created node
			temp->next=New;
			temp=New;

		}

		cout<<"\n Do you want to enter more elements ?(y/n)";
		cin>>ans;
	}while(ans=='y'||ans=='Y');

	cout<<"\n The singly linked list is created \n";

}


/* Display function */

void SymbolTable::display()
{

	node *temp;
	temp=head;
	if(temp==NULL)
	{

		cout<<"\n The Symbol Table is empty \n";
		return;
	}

	cout<<"\n The Symbol Table is.... \n";
	cout<<"\n ------------------------------";

	cout<<"\nIdentifier\tInitial Value\tLine Numbers";
	cout<<"\n ---------------------------------";

	while(temp!=NULL)
	{

		cout<<"\n"<<temp->identifier<<"\t\t"<<temp->initial_value<<"\t\t[";

		for(int i=0;i<=temp->total_lines_of_id;i++)
			cout<<temp->lines_no[i]<<" ";
		cout<<"]";
		temp=temp->next;
	}
	cout<<"\n -----------------------------\n ";

}

void SymbolTable::is_name_present()
{
	node *temp;
	string id;
	int status=FALSE;
	temp=head;
	
	if(temp==NULL)
	{
		cout<<"\n the list is empty \n";
		return;

	}

	cout<<"\n Enter the identifier to be searched for : ";

	cin>>id;

	while(temp!=NULL)
	{
		if(temp->identifier==id)
		{

			status=TRUE;
			break;
		}
		temp=temp->next;

	}

	if(status==TRUE)
		cout<<"\n The identifier"<<id<<"is present in the table";

	else

		cout<<"\n The identifier "<<id<<"is not present in the table";

}



void SymbolTable::retrieve_attributes()
{

	node *temp,*Element;
	string id;
	int status=FALSE;
	temp=head;
	Element=NULL;
	
	if(temp==NULL)
	{

		cout<<"\n The list is empty \n";
		return;
	}
	cout<<"\n Enter the identifier to be searched for:";
	cin>>id;

	while(temp!=NULL)
	{
		if(temp->identifier==id)
		{

			status=TRUE;
			Element=temp;
			break;
		}

		temp=temp->next;

	}

	if(status==TRUE)
	{

		cout<<"\n Identifier"<<Element->identifier;
		cout<<"\n Initial Value"<<Element->initial_value;
		cout<<"\n Line Numbers : [";

		for(int i=0;i<=Element->total_lines_of_id;i++)
		{
			cout<<Element->lines_no[i]<<" ";

		}

		cout<<"]";

	}

	else
		cout<<"\n The identifier "<<id<<"is not present in the table";

}


void SymbolTable::modify_attributes()
{

	node *temp,*Element;
	string id;
	int status=FALSE;
	temp=head;
	char ch='y';
	Element=NULL;
	
	if(temp==NULL)
	{

		cout<<"\n The list is empty \n";
		return;
	}
	cout<<"\n Enter the identifier to be modified:";
	cin>>id;

	while(temp!=NULL)
	{
		if(temp->identifier==id)
		{

			status=TRUE;
			Element=temp;
			break;
		}

		temp=temp->next;

	}

	if(status==TRUE)
	{

		cout<<"\n Identifier"<<Element->identifier;
		cout<<"\n Initial Value"<<Element->initial_value;
		cout<<"\n Line Numbers : [";

		for(int i=0;i<=Element->total_lines_of_id;i++)
		{
			cout<<Element->lines_no[i]<<" ";

		}

		cout<<"]";
		cout<<"\n Enter modified initial value";

		cin>>Element->initial_value;
		int j=0;

		do
		{
			cout<<"\n Enter line number:";
			cin>>Element->lines_no[j];
			j++;

			cout<<"\n Do u want to enter more line numbers ?";
			cin>>ch;

		}while(ch=='y'||ch=='Y');

		Element->total_lines_of_id=j-1;


	}
	
	else
		cout<<"\n The identifier "<<id<<"is not present in the table";

}

void SymbolTable::insert()
{
	node *New,*temp;
	char ch='y';

	New=new node;

	cout<<"\n Enter name of identifier";
	cin>>New->identifier;

	cout<<"\n Enter initial value";
	cin>>New->initial_value;

	int i=0;

	do
	{

		cout<<"\n Enter line number:";
		cin>>New->lines_no[i];
		i++;

		cout<<"\n Do u want to enter more line numbers ?";

		cin>>ch;		

	}while(ch=='y'||ch=='Y');
	
	New->total_lines_of_id=i-1;
	New->next=NULL;
	
	if(head==NULL)
		head=New;

	else
	{
		temp=head;
		while(temp->next!=NULL)
			temp=temp->next;

		temp->next=New;
		New->next=NULL;

	}
	

}

void SymbolTable::delete_id()
{

	node *temp,*prev;
	string key;
	temp=head;
	prev=NULL;
	
	if(temp==NULL)
		cout<<"\n The Symbol Table is Empty!!";

	else
	{

		cout<<"\n Enter the name of identifier you want to delete :";
		cin>>key;

		while(temp!=NULL)
		{
			if(temp->identifier==key) //traverse till required node to delete
				break;

			prev=temp;
			temp=temp->next;

		}

		if(temp==NULL)
		{
			cout<<"\n The desired identifier is not present in Symbol Table";
			return;

		}
		else
		{
			if(temp==head) //first node
				head=temp->next;
			else
			prev->next=temp->next; // intermediate or end node
			delete temp;

			cout<<"\n The Element is deleted \n";
		}

	}

}


int main()
{

	SymbolTable s;
	int choice;
	char ans='y';

	do
	{
			
		cout<<"\n Program for Symbol Table Operations";
		cout<<"\n 1.create";
		cout<<"\n 2.display";
		cout<<"\n 3.determine if name is present in table";
		cout<<"\n 4.Retrieve attributes if the name";
		cout<<"\n 5.Modify attributes if the name";
		cout<<"\n 6.insert new name & attributes";
		cout<<"\n 7.delete a name & attributes";
		cout<<"\n Enter your choice";
		cin>>choice;

		switch(choice)
		{
			case 1: s.create();
				break;

			case 2: s.display();
				break;


			case 3: s.is_name_present();
				break;

			case 4: s.retrieve_attributes();
				break;

			case 5: s.modify_attributes();
				break;

			case 6: s.insert();
		
				break;

			case 7: s.delete_id();
				break;

			default:cout<<"\n Invalid choice";
		}
		cout<<"\n Do u want to go to Main Menu ?";
		cin>>ans;		


	}while(ans=='y'||ans=='Y');
	


return 0;
}



