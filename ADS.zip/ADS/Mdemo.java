



import My_Package.circle;
import My_Package.rectangle;
import My_Package.perimeter;

class Mdemo
{
	public static void main(String[] args )
	{
		perimeter obj;
		circle obj1= new circle();
		rectangle obj2=new rectangle();
		
		System.out.println("\n\t Calculating Perimeter of Circle....\n");

		obj=obj1;
		obj.calculate();
		
		System.out.println("\n\t Calculating Perimeter of Rectangle ....\n");

		obj=obj2;
		obj.calculate();
	}

}
