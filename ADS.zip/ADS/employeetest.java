
// Assignment No. 13

class employee
{
	int employee_id;
	String employee_name;
	
	void display_employee_details(String emp[][])
	{
		System.out.println("\n----------------------------");
		System.out.println("\t\t EMPLOYEE DETAILS  ");
		System.out.println("\n----------------------------");
		

		System.out.println("Id \t Name");

		System.out.println("-------------------------------");
		
		for(int i=0;i<emp.length;i++)
		{
			System.out.println(emp[i][0]);
			System.out.println("\t"+emp[i][1]);
			System.out.println(" ");

		}
	}



}


class salary extends employee // derived class
{


	String designation;
	double monthly_salary;
	
	salary() //default constructor
	{}

	salary(int employee_id,String employee_name,String designation,double monthly_salary) //parameterized constructor
	{
		this.employee_id=employee_id;
		this.employee_name=employee_name;
		this.designation=designation;
		this.monthly_salary=monthly_salary;

	}

	void display_salary_details(String emp[][])
	{
		System.out.println("\n-------------------------------- ");
		System.out.println("\t\t SALARY DETAILS ");
		System.out.println("\n-------------------------------- ");
		System.out.println("Designation \t Salary ");
		System.out.println("---------------------------------- ");

		for(int i=0;i<emp.length;i++)
		{
			System.out.println(emp[i][2]);
			System.out.println("\t"+emp[i][3]);
			System.out.println(" ");

		}

			

	}

	void fun(String emp[][])	// function displaying salary > 20000
	{
		System.out.println("\n----------------------------- ");
		System.out.println("REPORT - HIGHLY PAID EMPLOYEES(Salary more that 20,000/-) ");	

		System.out.println("\n------------------------------ ");
		
		for(int i=0;i<emp.length;i++)
		{	

			if((Double.parseDouble(emp[i][3])) > 20000)
			{

				System.out.println("Id= " + emp[i][0]);
				System.out.println("Name= " + emp[i][1]);
				System.out.println("Designation= " + emp[i][2]);
				System.out.println("Salary= " + emp[i][3]);
				System.out.println("---------------------------------- ");

			}

		}

	}
	

}

public class employeetest
{

	public static void main(String args[])
	{

		salary obj[]=new salary[5];
		String Details[][];

		obj[0]=new salary(1,"AAA","Accountant",12000);
		obj[1]=new salary(2,"BBB","Manager",30000);
		obj[2]=new salary(3,"CCC","Excecutive",2000);
		obj[3]=new salary(4,"DDD","CEO",50000);
		obj[4]=new salary(5,"EEE","Developer",40000);

		Details= new String[obj.length][4];

		for(int i=0;i<obj.length;i++)
		{

			Details[i][0]=String.valueOf(obj[i].employee_id);
			Details[i][1]=obj[i].employee_name;
			Details[i][2]=obj[i].designation;
			Details[i][3]=String.valueOf(obj[i].monthly_salary);

		}


		obj[4].display_employee_details(Details);
		obj[4].display_salary_details(Details);
		obj[4].fun(Details);

	}

}
