
// assignment 3.2 
// Adjacency List Representation

#include<iostream>
using namespace std;

#define MAX 10
#define TRUE 1
#define FALSE 0

// Declaring an adjacency list for storing the graph

class Lgraph
{


private:

	typedef struct node1
	{
		int vertex;
		struct node1 *next;

	}node;

	node *head[MAX]; //Array of head nodes
	int visited[MAX]; //visited array for checking whether the array is visited or not
public:
	static int node_count;
	Lgraph();
	void create(),Dfs(int);


};


/* The Constructor defined */

Lgraph::Lgraph()
{
	int V1;
	
	for(V1=0;V1 < MAX;V1++)
		visited[V1]=FALSE;
	
	for(V1=0;V1 < MAX;V1++)
		head[V1]=NULL;

}

/* The create function */

void Lgraph::create()
{

	int V1,V2;
	char ans='y';

	node *New,*first;
	
	cout<<"\n \n Enter the vertices no. beginning with 0 ";

	do
	{
		cout<<"\n Enter the Edge of a graph \n";
		cin>>V1>>V2;

		if(V1 >= MAX || V2 >= MAX)
			cout<<"Invalid Vertex Value \n ";
		else
		{

			// Creating link from V1 to V2
			New = new node;
			
			if(New==NULL)
				cout<<"Insufficient Memory \n";

			New->vertex=V2;
			New->next=NULL;

			first=head[V1];

			if(first==NULL)
				head[V1]=New;

			else
			{
				while(first->next!=NULL)
					first=first->next;

					first->next=New;


			}

			// creating link from V2 to V1


			New =new node;
			if(New == NULL)
				cout<<"Insufficient Memory";

			New->vertex=V1;
			New->next=NULL;

			first=head[V2];

			if(first==NULL)
				head[V2]=New;
			else
			{
				while(first->next != NULL)
				first=first->next;
				first->next=New;

			}
		}

		cout<<"\n Want to add more edges ?(y/n)";
		cin>>ans;
	
	
	}while(ans=='y');

}


/*   Dfs function  */

void Lgraph::Dfs(int V1)
{

	node *first;
	cout<<endl<<V1;
	node_count++;
	visited[V1]=TRUE;
	first=head[V1];

	while(first!=NULL)
		if(visited[first->vertex]==FALSE)
			Dfs(first->vertex);
		else
			first=first->next;
	

}

int Lgraph::node_count=0;

/* The Main Function */


int main()
{

	int V1;
	Lgraph gr;
	gr.create();

	cout<<endl<<"Enter the vertex from which you want to traverse :";
	cin>>V1;
	
	if(V1 >= MAX)
		cout<<"Invalid Vertex \n";

	else
	{

		cout<<"The Depth First Search of Graph is \n ";
			gr.Dfs(V1);
	}
	cout<<"\n Total Number of nodes in Graph= "<<Lgraph::node_count;

return 0;
}


