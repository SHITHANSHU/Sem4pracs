package My_Package;
import java.io.*;
import java.util.*;

public class rectangle implements perimeter
{


	private double length,breadth;
	
	public void calculate()
	{

		System.out.print("Enter length :");
		Scanner input= new Scanner(System.in);

		double length=input.nextDouble();
		 
		System.out.print("Enter breadth :");
		double breadth=input.nextDouble();
		
		double p=2*(length+breadth);
		System.out.print("Perimeter of rectangle:"+p);
		
	}
	

}
