
package My_Package;

import java.io.*;
import java.util.*;
import java.util.Scanner;

public class circle implements perimeter
{

	private double r;
	public void calculate()
	{
		System.out.print("Enter radius");
		Scanner input=new Scanner(System.in);
		double r= input.nextDouble();
		double p=2*3.14*r;
		System.out.println("Perimeter of Circle: "+p);

	}

}
