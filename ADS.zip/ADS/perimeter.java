package My_Package;

public interface perimeter
{

	void calculate();
}
