
// Assignment No. 5

#include<iostream>
using namespace std;

#define MAX 10

class HashTab
{

private:
	struct DCT
	{
		int k;
		int val;
		

	}a[MAX];

public:
	int HashDivMethod(int);
	void init();
	void insert(int,int,int);
	void display();
	void size();
	int search(int);
	void deleteRec(int); 


};

void HashTab::init()
{
	for(int i=0;i< MAX ;i++)
	{
		a[i].k=-1;
		a[i].val=-1;

	}

}


int HashTab::HashDivMethod(int num)
{

	int Hkey;
	Hkey=num % 10;
	return Hkey;
	

}

void HashTab::insert(int index, int key, int value)
{

	int flag,i,count=0;
	flag=0;
	
	if(a[index].k==-1) // if the location indicated by hash key is empty

	{
		a[index].k=key;
		a[index].val=value;

	}
	else
	{
		i=0;
		while(i<MAX)
		{
			if(a[i].k!=-1)
				count++;
			i++;

		}

		if(count==MAX)
		{

			cout<<"\n Hash table is full";
		}
		for(i=index+1;i<MAX;i++) //moving linearly down
			if(a[i].k==-1) //searching for empty location
			{

				a[i].k=key;
				a[i].val=value;
				// placing the number at empty location
				flag=1;
				break;
				
			}

			/*from key position to the end of array we have searched empty location and now we want to check empty location in the upper part of the array */

		for(i=0;i<index && flag==0 ;i++) //array from 0th to keyth location will be scanned
			if(a[i].k==-1)
			{
				a[i].k=key;
				a[i].val=value;
				flag=1;
				break;

			}

	} //  outer else
}

void HashTab::display()
{
	int i;
	cout<<"\n The Hash Table is... \n";
	cout<<"\n---------------------";

	for(i=0;i<MAX;i++)
	{
		cout<<"\n"<<i<<" "<<a[i].k<<" "<<a[i].val;

	}
	cout<<"\n ---------------------";
}

void HashTab::size()
{
	int len=0,i;
	
	for(i=0;i<MAX;i++)
	{
		if(a[i].k!=-1)
			len++;
	}
	cout<<"\n The size of dictionary is";
	cout<<len;
}

int HashTab::search(int search_key)
{

	int i,j,status=0;
	i=HashDivMethod(search_key);

	if(a[i].k==search_key)
	{

		cout<<"The Record is present at location : "<<i;
		status=1;
		return i;
	}

	if(a[i].k!=search_key)
	{

		//searching from hash key to end of hash table
		for(j=i;j<MAX;j++)
		{
			if(a[j].k==search_key)
			{

				cout<<"\n The Record is present at location "<<j;
				status=1;
				// status 1 means record is present
				return j;

			}

		}

		for(j=0;j<i;j++)
		{
			if(a[j].k==search_key)
			{
				cout<<"\n The Record is present at location: "<<j;
				status=1;
				return j;

			}
		}

	}

	if(status==0)
	{

		cout<<"\n The Record is not present in the hash table ";
		return -99;
	}
	
}

void HashTab::deleteRec(int key)
{

	int index;
	index=search(key);
	if(index!=-99)
	{

		a[index].k=-1;
		a[index].val=-1;
		cout<<"\n The Record is deleted !!";

	}

}

int main()
{

	int key,value,Hkey,search_key,choice;
	char ans;
	int index;
	HashTab obj;
	cout<<"\n Dictionary Function using Hashing";
	obj.init();
	do
	{
		
		cout<<"\n 1.Insertion";
		cout<<"\n 2.Display";
		cout<<"\n 3.search";
		cout<<"\n 4.Deletion";
		cout<<"\n Enter your choice ";
		cin>>choice;

		switch(choice)
		{
			case 1:
			cout<<"\n Enter the key";
			cin>>key;

			cout<<"\n Enter the value";
			cin>>value;

			Hkey=obj.HashDivMethod(key); //returns hash key

			obj.insert(Hkey,key,value); //collision handled by linear probing
			break;

			case 2:
				obj.display(); // display hash table
				obj.size();
				break;

			case 3:
				cout<<"Enter the key for searching the record";
				cin>>search_key;
				index=obj.search(search_key);
				break;

			case 4:
				cout<<"\n Enter the key for deletion of the record";
				cin>>search_key;
				obj.deleteRec(search_key);
				break;
				
		}
		cout<<"\n Do U wish to continue ? (y/n)";
		cin>>ans;

	}while(ans=='y');
return 0;
}


